# 
# Yeji Kim-Barros
# Global.R for Shiny App in R
# 
# Stattleship xCase
# March 2018
# 

load("~/RData/Stattleship xCase/Stattleship/xCase1.RData")
library(ggplot2)
library(plotly)
library(shiny)
library(ggfortify)